*pandas.DataFrame.copy
https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.copy.html


*Python Pandas : How to Drop rows in DataFrame by conditions on column values
https://thispointer.com/python-pandas-how-to-drop-rows-in-dataframe-by-conditions-on-column-values/

* JUST TO REMIND ME OF LOC AND ILOC (ITS IN PT!!!)
https://medium.com/horadecodar/data-science-tips-02-como-usar-loc-e-iloc-no-pandas-fab58e214d87